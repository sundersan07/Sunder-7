
# CBO AI — Private Sales & Ops Assistant

A single-file Streamlit app that lets your team **ask natural-language questions** over your **CBO/Sales CSV exports** and get answers in tables instantly. Runs **entirely on your machine** — no cloud required by default.

## Features
- Upload CSVs (attendance, sales, stocks, distance logs, etc.). They are stored in a local SQLite database.
- "Ask (AI)" page: type prompts like “Top 10 hospitals by sales in July 2025 for Tamil Nadu” — the app turns it into SQL and returns a table.
- Role-based visibility (admin/manager/field) to hide sensitive columns (e.g., salary).
- Data Explorer with optional raw SQL box.
- Audit log of ingests and queries.
- Optional OpenAI text-to-SQL assist if you set `OPENAI_API_KEY` (not required).

## Quick Start
1. **Install Python 3.10+**  
2. **Create a virtual environment (recommended)**
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\Scripts\activate
   ```
3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```
4. **Run the app**
   ```bash
   streamlit run app.py
   ```
5. **Login**
   - `admin / admin123`
   - `manager / manager123`
   - `field / field123`  
   *Change defaults in `app.py` before production.*

6. **Upload your CSVs** from the **Admin** page. Then use **Ask (AI)** to query.

## Configure
- Change the DB file path via `CBO_AI_DB` env var. Default: `cbo_ai.db` in the same folder.
- To enable OpenAI-powered text-to-SQL (optional), set `OPENAI_API_KEY` env var. No data is sent unless you enable this.

## Security Notes
- This app is designed for **internal networks**. For production:
  - Put behind your company SSO/reverse proxy (e.g., NGINX, Cloudflare, Keycloak).
  - Rotate default passwords and manage users outside the app.
  - Host on an internal VM and limit who can reach it.

## Example Prompts
- “top 20 hospitals by sales this month in Kerala”
- “sum of value for brand ceftriaxone in July 2025”
- “top 10 KAM by units 2025-06 to 2025-08”

## FAQ
**Q: Will my data go to the cloud?**  
A: No. Everything is local unless you enable the optional OpenAI key.

**Q: Can I export results?**  
A: Yes, there’s a **Download CSV** button after each query.

**Q: Can we integrate with our CBO system automatically?**  
A: Start by scheduling CSV exports from CBO to a shared folder. Point this app (or a cron job) to ingest them regularly. For direct DB/API sync, create a small Python job that fetches from CBO and writes to the same SQLite database path (`CBO_AI_DB`).

---

© 2025 Aionios internal prototype. For guidance, contact your IT/security team before production rollout.
