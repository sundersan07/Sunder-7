
import os
import io
import re
import json
import time
import hashlib
import sqlite3
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional

import pandas as pd
import numpy as np
import streamlit as st

# Optional: if user sets OPENAI_API_KEY, enable Text-to-SQL "Assist" using OpenAI
USE_LLM = bool(os.environ.get("OPENAI_API_KEY"))

APP_TITLE = "CBO AI — Private Sales & Ops Assistant"
DB_PATH = os.environ.get("CBO_AI_DB", "cbo_ai.db")

# -------------------- Simple Auth --------------------
# This is minimal session-based auth suitable for internal use.
# For production, place the app behind your SSO or reverse proxy auth.
DEFAULT_USERS = {
    # username: {"password": sha256_hex, "role": "admin"|"manager"|"field"}
    "admin": {"password": hashlib.sha256("admin123".encode()).hexdigest(), "role": "admin"},
    "manager": {"password": hashlib.sha256("manager123".encode()).hexdigest(), "role": "manager"},
    "field": {"password": hashlib.sha256("field123".encode()).hexdigest(), "role": "field"},
}

def get_users() -> Dict[str, Dict[str, str]]:
    # You can also bind this to a secure JSON file or env var in production
    return DEFAULT_USERS

def login():
    st.session_state.setdefault("authed", False)
    st.session_state.setdefault("user", None)
    st.session_state.setdefault("role", None)

    if st.session_state["authed"]:
        return True

    st.title(APP_TITLE)
    st.caption("On-prem | No cloud by default | Your data stays local.")

    with st.form("login_form", clear_on_submit=False):
        username = st.text_input("Username", value="")
        password = st.text_input("Password", type="password", value="")
        submitted = st.form_submit_button("Sign in")

    if submitted:
        users = get_users()
        if username in users:
            hashed = hashlib.sha256(password.encode()).hexdigest()
            if hashed == users[username]["password"]:
                st.session_state["authed"] = True
                st.session_state["user"] = username
                st.session_state["role"] = users[username]["role"]
                st.success(f"Welcome, {username}!")
                return True
        st.error("Invalid credentials.")
        return False
    else:
        st.stop()

# -------------------- DB Helpers --------------------
def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn

def ensure_schema(conn):
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS meta_kv (
            k TEXT PRIMARY KEY,
            v TEXT
        );

        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL,
            user TEXT NOT NULL,
            action TEXT NOT NULL,
            details TEXT
        );
        """
    )
    conn.commit()

def audit(conn, user: str, action: str, details: Dict[str, Any]):
    conn.execute(
        "INSERT INTO audit_log (ts, user, action, details) VALUES (?, ?, ?, ?)",
        (datetime.utcnow().isoformat(), user, action, json.dumps(details)),
    )
    conn.commit()

# -------------------- Data Ingest --------------------
def infer_table_name(uploaded_file_name: str) -> str:
    base = re.sub(r"\.[A-Za-z0-9]+$", "", os.path.basename(uploaded_file_name))
    base = re.sub(r"[^a-zA-Z0-9_]+", "_", base).lower()
    return base[:48] or "table_" + hashlib.sha1(uploaded_file_name.encode()).hexdigest()[:8]

def load_csv_to_sqlite(conn, file_bytes: bytes, table_name: str, dtype_overrides: Optional[Dict[str, str]] = None):
    df = pd.read_csv(io.BytesIO(file_bytes))
    # Clean column names
    df.columns = [re.sub(r"[^a-zA-Z0-9_]+", "_", c.strip()).lower() for c in df.columns]
    # Write to SQLite (replace existing table with same name)
    df.to_sql(table_name, conn, if_exists="replace", index=False)
    return df

# Basic field-level RBAC: which columns are shown to which roles
ROLE_COLUMN_RULES = {
    "admin": {"exclude": []},
    "manager": {"exclude": ["salary", "ctc", "payer_info_private"]},
    "field": {"exclude": ["salary", "ctc", "payer_info_private", "strategic_note", "internal_flag"]},
}

def filter_columns_for_role(df: pd.DataFrame, role: str) -> pd.DataFrame:
    rules = ROLE_COLUMN_RULES.get(role, {"exclude": []})
    drop = [c for c in df.columns if c in rules["exclude"]]
    if drop:
        df = df.drop(columns=[c for c in drop if c in df.columns])
    return df

# -------------------- NL → SQL Lite Engine --------------------
# A pragmatic rules engine that covers common ops dashboards.
DATE_COLS_HINTS = ["date", "tx_date", "bill_date", "order_date", "invoice_date", "created_at"]
DIMENSION_HINTS = ["state", "zone", "region", "city", "district", "hospital", "account", "kam", "rep", "brand", "product", "molecule", "channel"]
METRIC_HINTS = ["units", "qty", "quantity", "value", "amount", "revenue", "sales", "gross", "net"]

def find_date_col(cols: List[str]) -> Optional[str]:
    for c in cols:
        if any(h in c for h in DATE_COLS_HINTS):
            return c
    for c in cols:
        # fallback: any column that looks like a date
        if c.endswith("_date"):
            return c
    return None

def find_metric_col(cols: List[str]) -> Optional[str]:
    for c in cols:
        if any(h in c for h in METRIC_HINTS):
            return c
    return None

def guess_group_by(text: str, cols: List[str]) -> Optional[str]:
    tx = text.lower()
    for d in DIMENSION_HINTS:
        for c in cols:
            if d == c or (d in c and len(c) <= len(d) + 6):
                if d in tx or c in tx:
                    return c
    return None

def parse_date_range(text: str) -> Optional[tuple]:
    # Supports phrases like "last month", "this month", "january 2024", "2024-07 to 2024-08", "between 1 jan and 31 jan"
    tx = text.lower().strip()
    now = datetime.now()
    if "last month" in tx:
        first = (now.replace(day=1) - timedelta(days=1)).replace(day=1)
        last = now.replace(day=1) - timedelta(days=1)
        return first.date(), last.date()
    if "this month" in tx:
        first = now.replace(day=1)
        last = now
        return first.date(), last.date()
    m = re.search(r"(20\d{2})-(\d{2})\s*(to|-)\s*(20\d{2})-(\d{2})", tx)
    if m:
        y1, m1, y2, m2 = int(m.group(1)), int(m.group(2)), int(m.group(4)), int(m.group(5))
        first = datetime(y1, m1, 1)
        last = (datetime(y2, m2, 1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        return first.date(), last.date()
    # Simple month year like "july 2025"
    months = {m.lower(): i for i, m in enumerate(["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"], start=1)}
    m2 = re.search(r"(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+(20\d{2})", tx)
    if m2:
        mm = months[m2.group(1)]
        yy = int(m2.group(2))
        first = datetime(yy, mm, 1)
        last = (first + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        return first.date(), last.date()
    return None

def make_basic_sql(table: str, text: str, cols: List[str]) -> str:
    date_col = find_date_col(cols)
    metric_col = find_metric_col(cols) or "*"
    group_by = guess_group_by(text, cols)

    where_clauses = []
    dr = parse_date_range(text)
    if dr and date_col:
        where_clauses.append(f"{date_col} BETWEEN '{dr[0]}' AND '{dr[1]}'")

    # simple equality filters like "state = Tamil Nadu", "product ceftriaxone"
    for c in cols:
        m = re.search(rf"{c}\s*=\s*([A-Za-z0-9 _\-\.]+)", text, flags=re.IGNORECASE)
        if m:
            val = m.group(1).strip().strip("'").strip('"')
            where_clauses.append(f"{c} = '{val}'")
        else:
            # pattern: "for Tamil Nadu", "in Kerala", "product ceftriaxone"
            m2 = re.search(rf"(for|in|brand|product|hospital)\s+([A-Za-z0-9 _\-\./]+)", text, flags=re.IGNORECASE)
            if m2 and c in ("state","city","brand","product","hospital","kam","rep"):
                val = m2.group(2).strip()
                where_clauses.append(f"{c} LIKE '%{val}%'")

    wc = (" WHERE " + " AND ".join(where_clauses)) if where_clauses else ""

    if "top" in text.lower() or "bottom" in text.lower():
        n = 10
        mn = re.search(r"(top|bottom)\s+(\d+)", text.lower())
        order = "DESC" if "top" in text.lower() else "ASC"
        if mn:
            n = int(mn.group(2))
        if group_by and metric_col != "*":
            return f"SELECT {group_by} AS grp, SUM({metric_col}) AS metric FROM {table}{wc} GROUP BY grp ORDER BY metric {order} LIMIT {n};"
        elif metric_col != "*":
            return f"SELECT * FROM {table}{wc} ORDER BY {metric_col} {order} LIMIT {n};"

    if group_by and metric_col != "*":
        return f"SELECT {group_by} AS grp, SUM({metric_col}) AS metric FROM {table}{wc} GROUP BY grp ORDER BY metric DESC;"
    elif metric_col != "*":
        return f"SELECT SUM({metric_col}) AS metric FROM {table}{wc};"
    else:
        return f"SELECT * FROM {table}{wc} LIMIT 1000;"

def run_sql(conn, sql: str) -> pd.DataFrame:
    try:
        df = pd.read_sql_query(sql, conn)
    except Exception as e:
        return pd.DataFrame({"error": [str(e)], "sql": [sql]})
    return df

# -------------------- UI --------------------
def main():
    if not login():
        return

    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Go to", ["Ask (AI)", "Data Explorer", "Admin"])

    conn = get_conn()
    ensure_schema(conn)

    # Which tables exist?
    tables = pd.read_sql_query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name;", conn)["name"].tolist()
    # Hide internal tables
    tables = [t for t in tables if t not in ("meta_kv", "audit_log")]

    if page == "Ask (AI)":
        st.header("Ask your data")
        if not tables:
            st.info("No data yet. Upload CSVs in the Admin tab.")
            st.stop()

        table = st.selectbox("Choose dataset/table", options=tables, index=0)
        cols = pd.read_sql_query(f"PRAGMA table_info({table});", conn)["name"].tolist()
        st.caption(f"Columns: {', '.join(cols)}")

        q = st.text_input("Ask in plain English (e.g., 'Top 10 hospitals by sales in July 2025 for Tamil Nadu')", value="")
        col1, col2 = st.columns([1,1])
        with col1:
            run_btn = st.button("Run")
        with col2:
            show_sql_flag = st.toggle("Show SQL")

        if run_btn and q.strip():
            sql = make_basic_sql(table, q, cols)
            df = run_sql(conn, sql)

            # Role-based column filter
            df = filter_columns_for_role(df, st.session_state["role"])

            if show_sql_flag:
                st.code(sql, language="sql")

            if "error" in df.columns:
                st.error("SQL error. You can switch to Data Explorer to query directly.")
                st.dataframe(df)
            else:
                st.success(f"Rows: {len(df)}")
                st.dataframe(df)

                # Export
                csv = df.to_csv(index=False).encode("utf-8")
                st.download_button("Download results (CSV)", data=csv, file_name="results.csv", mime="text/csv")

            audit(conn, st.session_state["user"], "ask_query", {"table": table, "q": q, "sql": sql, "rows": len(df)})

    elif page == "Data Explorer":
        st.header("Explore data")
        if not tables:
            st.info("No data yet. Upload CSVs in the Admin tab.")
            st.stop()

        table = st.selectbox("Table", options=tables, index=0)
        st.caption("Preview first 1000 rows (role-filtered).")

        df = pd.read_sql_query(f"SELECT * FROM {table} LIMIT 1000;", conn)
        df = filter_columns_for_role(df, st.session_state["role"])
        st.dataframe(df)

        st.subheader("Run custom SQL (advanced)")
        sql = st.text_area("SQL", value=f"SELECT * FROM {table} LIMIT 100;")
        if st.button("Execute SQL"):
            out = run_sql(conn, sql)
            out = filter_columns_for_role(out, st.session_state["role"])
            st.dataframe(out)
            audit(conn, st.session_state["user"], "sql_query", {"sql": sql, "rows": len(out)})

    elif page == "Admin":
        if st.session_state["role"] not in ("admin", "manager"):
            st.warning("Only admin/manager can access Admin.")
            st.stop()

        st.header("Admin")
        st.subheader("Upload CSV to create/replace a table")
        up = st.file_uploader("Upload CSV", type=["csv"])
        if up is not None:
            table_name = st.text_input("Table name (auto-inferred from file name)", value=infer_table_name(up.name))
            if st.button("Ingest"):
                df = load_csv_to_sqlite(conn, up.read(), table_name)
                st.success(f"Loaded {len(df)} rows into '{table_name}'.")
                audit(conn, st.session_state["user"], "ingest", {"table": table_name, "rows": len(df)})
                st.experimental_rerun()

        st.divider()
        st.subheader("Tables in database")
        if st.button("Refresh list"):
            st.experimental_rerun()
        st.write(tables)

        if st.session_state["role"] == "admin":
            st.divider()
            st.subheader("Security & Logs")
            st.caption("Rotate default passwords before production.")
            if st.button("Show last 200 audit events"):
                logs = pd.read_sql_query("SELECT * FROM audit_log ORDER BY id DESC LIMIT 200;", conn)
                st.dataframe(logs)

            st.caption("To change default users, edit the DEFAULT_USERS dict in app.py or place behind SSO.")

if __name__ == "__main__":
    main()
